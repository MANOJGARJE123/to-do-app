import React from 'react';
import FeaturesSection from '../components/FeaturesSection';

const FeaturesPage = () => {
  return (
    <div>
      <FeaturesSection />
    </div>
  );
};

export default FeaturesPage;
